#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <random>
#include "bplustree.h"

// Simple workload: mix of inserts and searches.
// Compile: g++ src/*.cpp benchmarks/benchmark.cpp -Iinclude -lpthread -O2 -o bench

using namespace std;
using Clock = chrono::high_resolution_clock;

void worker_insert(BPlusTree &tree, int id, int ops, int keyOffset) {
    std::mt19937 rng(id + 12345);
    for (int i = 0; i < ops; ++i) {
        int k = (rng() % 1000000) + keyOffset;
        tree.insert(k, k*2);
    }
}

void worker_search(BPlusTree &tree, int id, int ops, int keyOffset) {
    std::mt19937 rng(id + 54321);
    int found=0;
    for (int i = 0; i < ops; ++i) {
        int k = (rng() % 1000000) + keyOffset;
        int v = tree.search(k);
        if (v!=-1) ++found;
    }
    (void)found;
}

int main() {
    BPlusTree tree;

    int num_threads = 8;
    int ops_per_thread = 5000;

    vector<thread> threads;

    auto t1 = Clock::now();

    // half thread do inserts, half do searches
    for (int i = 0; i < num_threads/2; ++i)
        threads.emplace_back(worker_insert, std::ref(tree), i, ops_per_thread, i*100000);

    for (int i = num_threads/2; i < num_threads; ++i)
        threads.emplace_back(worker_search, std::ref(tree), i, ops_per_thread, (i-num_threads/2)*100000);

    for (auto &th : threads) th.join();

    auto t2 = Clock::now();
    double seconds = chrono::duration<double>(t2 - t1).count();
    long total_ops = (long)num_threads * ops_per_thread;
    cout << "Threads="<<num_threads<<" TotalOps="<<total_ops<<" Time(s)="<<seconds<<" Throughput(op/s)="<<(total_ops/seconds) <<"\n";
    return 0;
}
