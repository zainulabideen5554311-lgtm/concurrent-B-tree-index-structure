#include <iostream>
#include "bplustree.h"

int main() {
    BPlusTree tree;

    // simple interactive demo
    tree.insert(10, 100);
    tree.insert(20, 200);
    tree.insert(5, 50);

    std::cout << "Search 10 = " << tree.search(10) << "\n";
    std::cout << "Search 5  = " << tree.search(5) << "\n";

    return 0;
}
