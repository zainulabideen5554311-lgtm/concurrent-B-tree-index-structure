// Modified bplustree.cpp to use OptimisticRWLock if present
#include "bplustree.h"
#include "optimistic_rwlock.h"
#include <algorithm>

BPlusTree::BPlusTree(){ root = std::make_shared<Node>(true); }

int BPlusTree::search(int key) {
    auto curr = root;
    while (true) {
        // Try optimistic read first
        uint64_t v = curr->latch.beginOptimisticRead();
        if (curr->isLeaf) {
            for (int i = 0; i < curr->keys.size(); i++) {
                if (curr->keys[i] == key) {
                    if (curr->latch.validateOptimisticRead(v)) return curr->values[i];
                    break; // validation failed; fall back to locked path
                }
            }
            // fallback to locked read
            curr->latch.readLock();
            for (int i = 0; i < curr->keys.size(); i++) {
                if (curr->keys[i] == key) {
                    curr->latch.readUnlock();
                    return curr->values[i];
                }
            }
            curr->latch.readUnlock();
            return -1;
        }

        int i = 0;
        while (i < curr->keys.size() && key > curr->keys[i]) i++;

        // Before descending, attempt optimistic validation for this node
        if (curr->latch.validateOptimisticRead(v)) {
            curr = curr->children[i];
            continue;
        }

        // fallback to shared lock (latch coupling)
        curr->latch.readLock();
        auto child = curr->children[i];
        child->latch.readLock();
        curr->latch.readUnlock();
        curr = child;
    }
}

void BPlusTree::insert(int key, int value) {
    auto r = root;
    r->latch.readLock();
    if (r->keys.size() == MAX_KEYS) {
        r->latch.readUnlock();
        // need to split root under write lock
        r->latch.writeLock();
        auto s = std::make_shared<Node>(false);
        s->children.push_back(r);
        splitChild(s, 0);
        root = s;
        r->latch.writeUnlock();
        insertNonFull(root, key, value);
    } else {
        r->latch.readUnlock();
        insertNonFull(r, key, value);
    }
}

void BPlusTree::splitChild(std::shared_ptr<Node> parent, int index) {
    auto full = parent->children[index];
    // lock both parent (writer) and full (writer)
    parent->latch.writeLock();
    full->latch.writeLock();

    auto sibling = std::make_shared<Node>(full->isLeaf);
    int mid = MAX_KEYS / 2;

    sibling->keys.assign(full->keys.begin() + mid, full->keys.end());
    full->keys.erase(full->keys.begin() + mid, full->keys.end());

    if (full->isLeaf) {
        sibling->values.assign(full->values.begin() + mid, full->values.end());
        full->values.erase(full->values.begin() + mid, full->values.end());
        sibling->next = full->next;
        full->next = sibling;
    } else {
        sibling->children.assign(full->children.begin() + mid + 1, full->children.end());
        full->children.erase(full->children.begin() + mid + 1, full->children.end());
    }

    parent->keys.insert(parent->keys.begin() + index, sibling->keys[0]);
    parent->children.insert(parent->children.begin() + index + 1, sibling);

    // writers update version by unlocking via OptimisticRWLock writeUnlock which bumps version
    full->latch.writeUnlock();
    parent->latch.writeUnlock();
}

void BPlusTree::insertNonFull(std::shared_ptr<Node> node, int key, int value) {
    node->latch.readLock();
    if (node->isLeaf) {
        // upgrade to write
        node->latch.readUnlock();
        node->latch.writeLock();
        auto pos = std::lower_bound(node->keys.begin(), node->keys.end(), key);
        int idx = pos - node->keys.begin();
        node->keys.insert(pos, key);
        node->values.insert(node->values.begin() + idx, value);
        node->latch.writeUnlock();
        return;
    }

    int i = node->keys.size() - 1;
    while (i >= 0 && key < node->keys[i]) i--;
    i++;
    auto child = node->children[i];
    // latch coupling: lock child before unlocking parent
    child->latch.readLock();
    node->latch.readUnlock();

    if (child->keys.size() == MAX_KEYS) {
        child->latch.readUnlock();
        // need to split under parent write
        node->latch.writeLock();
        splitChild(node, i);
        node->latch.writeUnlock();
        if (key > node->keys[i]) i++;
    } else {
        child->latch.readUnlock();
    }

    insertNonFull(node->children[i], key, value);
}
