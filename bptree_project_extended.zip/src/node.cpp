#include "node.h"
Node::Node(bool leaf) {
    isLeaf = leaf;
    next = nullptr;
}
