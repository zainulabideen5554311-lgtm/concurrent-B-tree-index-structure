# Design & Concurrency Enhancements

This document explains the concurrency improvements added to the base
concurrent B+Tree implementation.

## Goals
- Improve read throughput by adding an **optimistic read** path.
- Keep fine-grained locking using per-node locks.
- Provide a multithreaded benchmark to measure throughput and latency.

## Optimistic Reads
Each node exposes a version counter (`uint64_t version`). Writers increment
the version before and after structural changes. Readers may:

1. Read the version (v1).
2. Traverse the node without acquiring an exclusive lock.
3. Read the version again (v2).
4. If v1 == v2 and v1 is even, the read is considered valid.
5. On validation failure, fall back to acquiring shared locks (safe read).

This reduces lock contention for read-heavy workloads.

## Latch Coupling
Traversal uses latch coupling: a reader/writer locks the child before
releasing the parent (when necessary) to avoid races with concurrent structural
changes (splits/merges).

## Benchmarks
See `benchmarks/benchmark.cpp` for a configurable test harness that runs
multiple threads performing mixed insert/search workloads and reports
throughput and basic latency statistics.

