#ifndef NODE_H
#define NODE_H

#include <vector>
#include <memory>
#include "optimistic_rwlock.h"

const int MAX_KEYS = 4;

class Node {
public:
    bool isLeaf;
    std::vector<int> keys;
    std::vector<std::shared_ptr<Node>> children;
    std::vector<int> values;

    // Use the optimistic lock for versioning & shared locks
    OptimisticRWLock latch;
    std::shared_ptr<Node> next; // for leaf chaining

    Node(bool leaf=false);
};

#endif
