#ifndef OPTIMISTIC_RWLOCK_H
#define OPTIMISTIC_RWLOCK_H

#include <shared_mutex>
#include <atomic>
#include <cstdint>

// Simple versioned read/write lock to allow optimistic reads.
// Writers increment the version before and after mutations.
// Optimistic readers sample the version and validate later.
class OptimisticRWLock {
private:
    std::shared_mutex mtx;
    std::atomic<uint64_t> version{0};

public:
    // Writer locks (exclusive). Increment version to mark mutation.
    void writeLock() {
        mtx.lock();
        // mark writer in-progress by making version odd
        version.fetch_add(1, std::memory_order_acq_rel);
    }
    void writeUnlock() {
        // increment to make version even and signal new stable state
        version.fetch_add(1, std::memory_order_acq_rel);
        mtx.unlock();
    }

    // Shared lock for readers
    void readLock() { mtx.lock_shared(); }
    void readUnlock() { mtx.unlock_shared(); }

    // Optimistic read: return a snapshot version to validate later.
    uint64_t beginOptimisticRead() const {
        return version.load(std::memory_order_acquire);
    }
    // Validate previously observed version. Returns true if no writer intervened.
    bool validateOptimisticRead(uint64_t v) const {
        return v == version.load(std::memory_order_acquire) && (v % 2 == 0);
    }
};

#endif
