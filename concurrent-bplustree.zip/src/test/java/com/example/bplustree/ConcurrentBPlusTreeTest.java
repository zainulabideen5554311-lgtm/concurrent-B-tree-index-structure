package com.example.bplustree;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.*;

public class ConcurrentBPlusTreeTest {
    @Test
    public void simpleInsertSearch() {
        ConcurrentBPlusTree<Integer,String> t = new ConcurrentBPlusTree<>(4);
        t.insert(10, "a");
        t.insert(20, "b");
        t.insert(15, "c");
        assertEquals("b", t.search(20));
        assertEquals("c", t.search(15));
    }

    @Test
    public void concurrentStress() throws InterruptedException {
        ConcurrentBPlusTree<Integer,String> t = new ConcurrentBPlusTree<>(8);
        int threads = 6; int per = 2000;
        ExecutorService ex = Executors.newFixedThreadPool(threads);
        for (int i=0;i<threads;i++) {
            final int base = i*per;
            ex.submit(() -> { for (int j=0;j<per;j++) t.insert(base+j, "v"+(base+j)); });
        }
        ex.shutdown(); ex.awaitTermination(60, TimeUnit.SECONDS);
        // verify
        for (int i=0;i<threads*per;i++) assertEquals("v"+i, t.search(i));
    }
}
