package com.example.bplustree;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

/**
 * Concurrent B+ Tree (in-memory)
 * - Generic K extends Comparable, V value
 * - Node-level ReentrantLock latches
 * - Simple optimistic read: node version stamp validated for read path
 * - Insert, search, delete, and range scan
 * - Order = max children per internal node
 */
public class ConcurrentBPlusTree<K extends Comparable<K>, V> {
    private final int order;
    private volatile Node root;

    // Node version increments on structural change (split/merge/insert/delete)
    private static class VersionedLock extends ReentrantLock {
        final AtomicLong version = new AtomicLong(0);
        void bumpVersion() { version.incrementAndGet(); }
        long getVersion() { return version.get(); }
    }

    private abstract class Node {
        final VersionedLock lock = new VersionedLock();
        InternalNode parent;
        abstract boolean isLeaf();
    }

    private class InternalNode extends Node {
        final ArrayList<K> keys = new ArrayList<>();
        final ArrayList<Node> children = new ArrayList<>();
        @Override boolean isLeaf() { return false; }
    }

    private class LeafNode extends Node {
        final ArrayList<K> keys = new ArrayList<>();
        final ArrayList<V> values = new ArrayList<>();
        LeafNode next;
        @Override boolean isLeaf() { return true; }
    }

    public ConcurrentBPlusTree(int order) {
        if (order < 3) throw new IllegalArgumentException("order must be >=3");
        this.order = order;
        this.root = new LeafNode();
    }

    /* ---------------- Public API ---------------- */
    public V search(K key) {
        // optimistic descent: read version stamps; validate at leaf
        while (true) {
            Node n = root;
            long rootVer = ((VersionedLock)n.lock).getVersion();
            while (!n.isLeaf()) {
                InternalNode in = (InternalNode)n;
                int idx = findChildIndex(in.keys, key);
                n = in.children.get(idx);
            }

            LeafNode leaf = (LeafNode)n;
            int pos = Collections.binarySearch(leaf.keys, key);
            V result = (pos >= 0) ? leaf.values.get(pos) : null;

            // validate: ensure versions on path didn't change
            if (validatePath(key, rootVer)) return result;
            // else retry
        }
    }

    public void insert(K key, V value) {
        // standard lock-coupling insertion
        Node n = root;
        n.lock.lock();
        try {
            while (!n.isLeaf()) {
                InternalNode in = (InternalNode)n;
                int idx = findChildIndex(in.keys, key);
                Node child = in.children.get(idx);
                child.lock.lock();
                n.lock.unlock();
                n = child;
            }
            LeafNode leaf = (LeafNode)n;
            int pos = Collections.binarySearch(leaf.keys, key);
            if (pos >= 0) {
                leaf.values.set(pos, value);
                leaf.lock.bumpVersion();
                return;
            }
            int insertPos = -pos - 1;
            leaf.keys.add(insertPos, key);
            leaf.values.add(insertPos, value);
            leaf.lock.bumpVersion();
            if (leaf.keys.size() > order - 1) splitLeaf(leaf);
        } finally {
            // release any lock we may still hold
            releaseIfHeld(root);
        }
    }

    public boolean delete(K key) {
        // lock-coupling to leaf
        Node n = root;
        n.lock.lock();
        try {
            while (!n.isLeaf()) {
                InternalNode in = (InternalNode)n;
                int idx = findChildIndex(in.keys, key);
                Node child = in.children.get(idx);
                child.lock.lock();
                n.lock.unlock();
                n = child;
            }
            LeafNode leaf = (LeafNode)n;
            int pos = Collections.binarySearch(leaf.keys, key);
            if (pos < 0) return false;
            leaf.keys.remove(pos);
            leaf.values.remove(pos);
            leaf.lock.bumpVersion();
            // handle underflow: try redistribute or merge
            if (leaf != root && leaf.keys.size() < (order - 1) / 2) {
                handleLeafUnderflow(leaf);
            }
            return true;
        } finally {
            releaseIfHeld(root);
        }
    }

    public void rangeScan(K fromKey, K toKey, Consumer<Map.Entry<K,V>> consumer) {
        Node n = root;
        while (!n.isLeaf()) {
            InternalNode in = (InternalNode)n;
            int idx = findChildIndex(in.keys, fromKey);
            n = in.children.get(idx);
        }
        LeafNode leaf = (LeafNode)n;
        while (leaf != null) {
            for (int i = 0; i < leaf.keys.size(); i++) {
                K k = leaf.keys.get(i);
                if (k.compareTo(fromKey) < 0) continue;
                if (k.compareTo(toKey) >= 0) return;
                consumer.accept(new AbstractMap.SimpleEntry<>(k, leaf.values.get(i)));
            }
            leaf = leaf.next;
        }
    }

    /* ---------------- Internal helpers ---------------- */

    private int findChildIndex(List<K> keys, K key) {
        int idx = Collections.binarySearch(keys, key);
        if (idx >= 0) return idx + 1;
        return -idx - 1;
    }

    // validate path for optimistic read by checking root version stability and walking down
    private boolean validatePath(K key, long knownRootVersion) {
        // quick check: root version
        VersionedLock rl = ((VersionedLock)root.lock);
        if (rl.getVersion() != knownRootVersion) return false;
        // conservative: perform a locked descent but without modifying; acquire and release briefly
        Node n = root;
        n.lock.lock();
        try {
            while (!n.isLeaf()) {
                InternalNode in = (InternalNode)n;
                int idx = findChildIndex(in.keys, key);
                Node child = in.children.get(idx);
                child.lock.lock();
                n.lock.unlock();
                n = child;
            }
            // release leaf
            n.lock.unlock();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void splitLeaf(LeafNode leaf) {
        // caller holds leaf.lock
        int mid = (leaf.keys.size() + 1) / 2;
        LeafNode newLeaf = new LeafNode();
        for (int i = leaf.keys.size() - 1; i >= mid; i--) {
            newLeaf.keys.add(0, leaf.keys.remove(i));
            newLeaf.values.add(0, leaf.values.remove(i));
        }
        newLeaf.next = leaf.next;
        leaf.next = newLeaf;
        leaf.lock.bumpVersion();
        newLeaf.lock.bumpVersion();
        K promote = newLeaf.keys.get(0);

        if (leaf.parent == null) {
            InternalNode r = new InternalNode();
            r.keys.add(promote);
            r.children.add(leaf);
            r.children.add(newLeaf);
            leaf.parent = r; newLeaf.parent = r;
            root = r;
            return;
        }
        insertIntoParent(leaf.parent, promote, newLeaf);
    }

    private void insertIntoParent(InternalNode parent, K key, Node newChild) {
        parent.lock.lock();
        try {
            int idx = findChildIndex(parent.keys, key);
            parent.keys.add(idx, key);
            parent.children.add(idx + 1, newChild);
            newChild.parent = parent;
            parent.lock.bumpVersion();
            if (parent.children.size() > order) splitInternal(parent);
        } finally {
            parent.lock.unlock();
        }
    }

    private void splitInternal(InternalNode node) {
        node.lock.lock();
        try {
            int mid = node.keys.size() / 2;
            K promote = node.keys.get(mid);
            InternalNode sibling = new InternalNode();
            for (int i = node.keys.size() - 1; i >= mid + 1; i--) {
                sibling.keys.add(0, node.keys.remove(i));
            }
            for (int i = node.children.size() - 1; i >= mid + 1; i--) {
                Node c = node.children.remove(i);
                sibling.children.add(0, c);
                c.parent = sibling;
            }
            node.keys.remove(mid);
            node.lock.bumpVersion(); sibling.lock.bumpVersion();
            if (node.parent == null) {
                InternalNode nr = new InternalNode();
                nr.keys.add(promote);
                nr.children.add(node);
                nr.children.add(sibling);
                node.parent = nr; sibling.parent = nr; root = nr;
            } else {
                insertIntoParent(node.parent, promote, sibling);
            }
        } finally {
            node.lock.unlock();
        }
    }

    private void handleLeafUnderflow(LeafNode leaf) {
        # try borrow from right sibling, then left; else merge
        leaf.lock.lock();
        try {
            InternalNode parent = leaf.parent;
            if (parent == null) return; // root leaf
            int idx = parent.children.indexOf(leaf);
            LeafNode left = (idx > 0) ? (LeafNode) parent.children.get(idx - 1) : null;
            LeafNode right = (idx + 1 < parent.children.size()) ? (LeafNode) parent.children.get(idx + 1) : null;

            if (right != null) {
                right.lock.lock();
                try {
                    if (right.keys.size() > (order - 1) / 2) {
                        # borrow first from right
                        leaf.keys.add(right.keys.remove(0));
                        leaf.values.add(right.values.remove(0));
                        leaf.lock.bumpVersion(); right.lock.bumpVersion();
                        parent.keys.set(idx, right.keys.get(0));
                        return;
                    }
                } finally { right.lock.unlock(); }
            }

            if (left != null) {
                left.lock.lock();
                try {
                    if (left.keys.size() > (order - 1) / 2) {
                        # borrow last from left
                        leaf.keys.add(0, left.keys.remove(left.keys.size()-1));
                        leaf.values.add(0, left.values.remove(left.values.size()-1));
                        leaf.lock.bumpVersion(); left.lock.bumpVersion();
                        parent.keys.set(idx-1, leaf.keys.get(0));
                        return;
                    }
                } finally { left.lock.unlock(); }
            }

            # Merge: prefer merging with right if exists
            if (right != null) {
                right.lock.lock();
                try {
                    # move all keys from right to leaf
                    leaf.keys.addAll(right.keys);
                    leaf.values.addAll(right.values);
                    leaf.next = right.next;
                    leaf.lock.bumpVersion(); right.lock.bumpVersion();
                    # remove right from parent
                    parent.lock.lock();
                    try {
                        int ridx = parent.children.indexOf(right);
                        parent.children.remove(ridx);
                        parent.keys.remove(ridx-1);
                        parent.lock.bumpVersion();
                        if (parent == root && parent.children.size() == 1) {
                            root = parent.children.get(0);
                            root.parent = null;
                        } else if (parent != root && parent.children.size() < (order+1)/2) {
                            handleInternalUnderflow(parent);
                        }
                    } finally { parent.lock.unlock(); }
                } finally { right.lock.unlock(); }
            } else if (left != null) {
                left.lock.lock();
                try {
                    left.keys.addAll(leaf.keys);
                    left.values.addAll(leaf.values);
                    left.next = leaf.next;
                    left.lock.bumpVersion(); leaf.lock.bumpVersion();
                    parent.lock.lock();
                    try {
                        int lidx = parent.children.indexOf(leaf);
                        parent.children.remove(lidx);
                        parent.keys.remove(lidx-1);
                        parent.lock.bumpVersion();
                        if (parent == root && parent.children.size() == 1) {
                            root = parent.children.get(0);
                            root.parent = null;
                        } else if (parent != root && parent.children.size() < (order+1)/2) {
                            handleInternalUnderflow(parent);
                        }
                    } finally { parent.lock.unlock(); }
                } finally { left.lock.unlock(); }
            }
        } finally {
            # ensure leaf lock released if still held
            if (leaf.lock.isHeldByCurrentThread()) {
                while (leaf.lock.getHoldCount() > 0) leaf.lock.unlock();
            }
        }
    }

    private void handleInternalUnderflow(InternalNode node) {
        // simplified: propagate similar to leaf underflow (borrow/merge)
        if (node.parent == null) return;
        node.lock.lock();
        try {
            InternalNode parent = node.parent;
            int idx = parent.children.indexOf(node);
            InternalNode left = (idx > 0) ? (InternalNode) parent.children.get(idx-1) : null;
            InternalNode right = (idx+1 < parent.children.size()) ? (InternalNode) parent.children.get(idx+1) : null;
            if (right != null && right.children.size() > (order+1)/2) {
                right.lock.lock();
                try {
                    // rotate from right
                    node.keys.add(parent.keys.get(idx));
                    parent.keys.set(idx, right.keys.remove(0));
                    node.children.add(right.children.remove(0));
                    node.lock.bumpVersion(); right.lock.bumpVersion(); parent.lock.bumpVersion();
                    return;
                } finally { right.lock.unlock(); }
            }
            if (left != null && left.children.size() > (order+1)/2) {
                left.lock.lock();
                try {
                    node.keys.add(0, parent.keys.get(idx-1));
                    parent.keys.set(idx-1, left.keys.remove(left.keys.size()-1));
                    node.children.add(0, left.children.remove(left.children.size()-1));
                    node.lock.bumpVersion(); left.lock.bumpVersion(); parent.lock.bumpVersion();
                    return;
                } finally { left.lock.unlock(); }
            }
            // merge
            if (right != null) {
                right.lock.lock();
                try {
                    node.keys.add(parent.keys.remove(idx));
                    node.keys.addAll(right.keys);
                    node.children.addAll(right.children);
                    parent.children.remove(idx+1);
                    node.lock.bumpVersion(); right.lock.bumpVersion(); parent.lock.bumpVersion();
                } finally { right.lock.unlock(); }
            } else if (left != null) {
                left.lock.lock();
                try {
                    left.keys.add(parent.keys.remove(idx-1));
                    left.keys.addAll(node.keys);
                    left.children.addAll(node.children);
                    parent.children.remove(idx);
                    left.lock.bumpVersion(); node.lock.bumpVersion(); parent.lock.bumpVersion();
                } finally { left.lock.unlock(); }
            }
            if (parent == root && parent.children.size() == 1) {
                root = parent.children.get(0);
                root.parent = null;
            } else if (parent != root && parent.children.size() < (order+1)/2) {
                handleInternalUnderflow(parent);
            }
        } finally {
            if (node.lock.isHeldByCurrentThread()) while (node.lock.getHoldCount()>0) node.lock.unlock();
        }
    }

    private void releaseIfHeld(Node n) {
        if (n == null) return;
        VersionedLock l = (VersionedLock)n.lock;
        if (l.isHeldByCurrentThread()) {
            while (l.getHoldCount() > 0) l.unlock();
        }
    }

    /* ---------------- Debug ---------------- */
    public void debugPrint() {
        Queue<Node> q = new LinkedList<>(); q.add(root);
        while (!q.isEmpty()) {
            int s = q.size();
            for (int i=0;i<s;i++) {
                Node n = q.poll();
                if (n.isLeaf()) {
                    LeafNode lf = (LeafNode)n;
                    System.out.print("[L:"+lf.keys+"] ");
                } else {
                    InternalNode in = (InternalNode)n;
                    System.out.print("[I:"+in.keys+"] ");
                    q.addAll(in.children);
                }
            }
            System.out.println();
        }
    }
}
