package com.example.bplustree;

import java.util.concurrent.*;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        ConcurrentBPlusTree<Integer, String> tree = new ConcurrentBPlusTree<>(8);
        int nThreads = 8;
        ExecutorService ex = Executors.newFixedThreadPool(nThreads);
        int per = 2000;
        for (int t=0;t<nThreads;t++) {
            final int base = t*per;
            ex.submit(() -> {
                for (int i=0;i<per;i++) tree.insert(base + i, "v" + (base+i));
            });
        }
        ex.shutdown(); ex.awaitTermination(60, TimeUnit.SECONDS);
        System.out.println("Insert done. Debug print:");
        tree.debugPrint();
        System.out.println("Searching sample keys:");
        System.out.println("key 42 -> " + tree.search(42));
        tree.rangeScan(10, 20, e -> System.out.println(e.getKey()+" -> "+e.getValue()));
    }
}
