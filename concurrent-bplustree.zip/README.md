# Concurrent B+ Tree (Java Maven)

## Overview
An in-memory concurrent B+ Tree implementation supporting concurrent inserts, searches, deletes, and efficient range scans. Uses node-level `ReentrantLock` with conservative optimistic reads through version checks.

## Build

```bash
mvn clean package
```

## Run demo

```bash
java -cp target/concurrent-bplustree-1.0-SNAPSHOT.jar com.example.bplustree.Main
```

## Tests

```bash
mvn test
```

## Notes
- The implementation is intentionally clear and educational but production-ready in many structural aspects (splits/merges, concurrency latches).
- TODO: WAL/persistence, lock-free optimizations, `StampedLock` optimistic readers, bulk-load.

Included in this package:
- src/main/java/com/example/bplustree/ConcurrentBPlusTree.java
- src/main/java/com/example/bplustree/Main.java
- src/test/java/com/example/bplustree/ConcurrentBPlusTreeTest.java

A screenshot of the project brief is included in `docs/` as well.
